# reset
rm(list=ls())
gc(reset=T)

# library
library(flexdashboard)
library(data.table)
library(knitr)
library(kableExtra)
library(plotly)
library(dplyr)
library(grid)
library(gridExtra)
library(leaflet)
library(leaflet.extras)
library(RColorBrewer)
library(KoNLP)
library(tm)
library(stringr)
library(readr)
library(plotly)
library(wordcloud2)
library(wordcloud)
library(DT)

# set path 
PATH_INPUT = "c:/Users/11900053/MITM/input"
PATH_OUTPUT = "c:/Users/11900053/MITM/output"
PATH_CODE = "c:/Users/11900053/MITM/code"

# set options
min_nchar = 2
min_freq = 2
remove_dic = c("����","���")

# list_folders
list_folders = dir(file.path(PATH_INPUT,"txt"))
up_to_date_folder = sort(list_folders,decreasing = T)[1]
cat(">> up_to_date_folder:",up_to_date_folder,"\n")

# title
MITM_TITLE_CLEAN_TXT_LIST = list()
MITM_TITLE_RAW_TXT_LIST = list()
for(i in list.files(file.path(PATH_INPUT,"txt",up_to_date_folder))){
  fileName = i
  source(file.path(PATH_CODE,"101_MITM100(title).R"))
  MITM_TITLE_RAW_TXT_LIST[[fileName]] = data.table(fileName,data.table(content=strsplit(MITM_RAW_TXT,"\n")))
  MITM_TITLE_CLEAN_TXT_LIST[[fileName]] = MITM_CLEAN_TXT
}
MITM_TITLE_CLEAN_TXT_DT = rbindlist(MITM_TITLE_CLEAN_TXT_LIST)
MITM_TITLE_RAW_TXT_DT = rbindlist(MITM_TITLE_RAW_TXT_LIST)
head(MITM_TITLE_CLEAN_TXT_DT)
head(MITM_TITLE_RAW_TXT_DT)

# save
tmp = paste0(strsplit(up_to_date_folder,"_")[[1]][2],"_","MITM_TITLE_CLEAN_TXT_DT.csv")
fwrite(MITM_TITLE_CLEAN_TXT_DT,file.path(PATH_OUTPUT,tmp))
cat(">>",tmp,"saved! \n")

# content
MITM_CONTENT_CLEAN_TXT_LIST = list()
MITM_CONTENT_RAW_TXT_LIST = list()
for(i in list.files(file.path(PATH_INPUT,"txt",up_to_date_folder))){
  fileName = i
  source(file.path(PATH_CODE,"102_MITM100(content).R"))
  MITM_CONTENT_RAW_TXT_LIST[[fileName]] = data.table(fileName,data.table(content=strsplit(MITM_RAW_TXT,"\n")))
  MITM_CONTENT_CLEAN_TXT_LIST[[fileName]] = MITM_CLEAN_TXT
}
MITM_CONTENT_CLEAN_DT = rbindlist(MITM_CONTENT_CLEAN_TXT_LIST)
MITM_CONTENT_RAW_TXT_DT = rbindlist(MITM_CONTENT_RAW_TXT_LIST)
head(MITM_CONTENT_CLEAN_DT)
head(MITM_CONTENT_RAW_TXT_DT)

# save
tmp = paste0(strsplit(up_to_date_folder,"_")[[1]][2],"_","MITM_CONTENT_CLEAN_DT.csv")
fwrite(MITM_CONTENT_CLEAN_DT,file.path(PATH_OUTPUT,tmp))
cat(">>",tmp,"saved! \n")

# cum_documents
cum_documents = list()
for(i in grep(pattern = "CONTENT",file.path(PATH_OUTPUT,list.files(PATH_OUTPUT)),value=T)){
  date = strsplit(gsub(".*/","",i),"_")[[1]][1]
  cum_documents[[as.character(paste(substr(date,1,4),substr(date,5,6),substr(date,7,8),sep="-"))]] = fread(i,encoding = "UTF-8")
}

# barchart
# topN = 30
# source(file.path(PATH_CODE,"102_MITM100(barchart).R"))

# wordcloud
# min_wordCNT = 5
# source(file.path(PATH_CODE,"103_MITM100(wordcloud).R"))













