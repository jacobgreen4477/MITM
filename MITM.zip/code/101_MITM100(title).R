# title : 101_MITM100.R
# author : hjy

# read data 
cat(">> read.. ",fileName,"\n")
data = fileName

# remove txt
data = gsub(".txt","",data)

# remove special characters
data = stringr::str_remove_all(data,"[0-9]")
data = stringr::str_remove_all(data,"[[:punct:]]")
data = stringr::str_remove_all(data,"[�������>��`~`��`��+Ҵ�����ޢ�����<�ܡ��§�߾�ꢡ���������]")

# remove space
data = gsub("\\s+", " ", data)
data = stringr::str_trim(data)

# MITM_RAW_TXT
data = data[data!=""]
#data = data[nchar(data)>=2]
MITM_RAW_TXT = data
  
# extractNoun
data = extractNoun(data)

# remove short_short_length
# cat(">> min_nchar:",min_nchar,"\n")
# data = lapply(data,function(x) x[nchar(x)>=min_nchar])

# combine
data = unlist(data)

# remove words 
# cat(">> remove_dic:",remove_dic,"\n")
# for(i in 1:length(remove_dic)){
#  cat(">> remove word(s):",remove_dic[i],"\n")
#  data = stringr::str_replace_all(data, remove_dic[i],'')
#  data = data[data!=""]
# }

# MITM_CLEAN_TXT
MITM_CLEAN_TXT = data.table(data)
head(MITM_CLEAN_TXT)

# data_W_freq
# cat(">> min_freq:",min_freq,"\n")
MITM_FREQ_TBL = data.table(table(MITM_CLEAN_TXT))
MITM_FREQ_TBL = MITM_FREQ_TBL[order(N,decreasing=T),]
# MITM_FREQ_TBL = MITM_FREQ_TBL[N>=min_freq,]
head(MITM_FREQ_TBL)

# save
# fwrite(MITM_CLEAN_TXT,file.path(PATH_OUTPUT,paste0("MITM_CLEAN_TXT_",gsub(" ","",gsub(".txt","",fileName)),".csv")))

# log
cat(">> 101_MITM100 done! \n")







