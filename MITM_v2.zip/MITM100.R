# title : MITM100.R
# author : hjy

# reset
rm(list=ls())
gc(reset=T)

# library
library(rmarkdown)
library(knitr)

# set path 
PATH_PRJT = "c:/Users/11900053/MITM"

# run 
tmp = file.path(PATH_PRJT,"html",paste0(gsub("-","",Sys.Date()),"_","MITM100.html"))
rmarkdown::render(file.path(PATH_PRJT,"MITM100.Rmd"), output_file = tmp)


